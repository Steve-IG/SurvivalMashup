# Companions

**Status:** Living Specification  
**Version:** 1.0  
**Owner:** Lead Systems Designer  
**Last Updated:** June 2026

---

## System Ownership

This system owns:
- Companion design rules, roles, progression model, active companion expectations, and companion synergy goals.

This system does NOT own:
- Ability execution, AI framework behavior, Equipment rules, Loot generation, or Relationship attribution.

Primary Responsibilities:
- Define collectible, upgradeable allies that support combat, exploration, utility, and world interaction.

Primary Data:
- Companion definitions, roles, affinities, progression data, and ability references.

Primary Runtime Objects:
- Companion instances, active companion selection, bond state, and companion progression state.

Published Events:
- TBD

Consumed Events:
- TBD

---

# Purpose

Companions are long-term allies that accompany the player throughout their journey.

They are not disposable summons or temporary combat pets. They are collectible, upgradeable companions that become trusted partners in exploration, combat, and world interaction.

Players should develop an emotional attachment to their companions while enjoying the strategic depth that comes from building a diverse roster.

---

# Design Philosophy

Companions should:

- Feel alive.
- Grow alongside the player.
- Encourage experimentation.
- Create new gameplay opportunities.
- Support many different playstyles.
- Be useful both inside and outside of combat.

The player is always the hero.

Companions enhance the player's abilities rather than replacing them.

---

# Companion Progression

The player begins the game with no companions.

The first companion is earned early in the adventure and serves as the player's introduction to the companion system.

As the game progresses, the player builds a growing collection of companions.

Each companion represents a long-term investment rather than a temporary resource.

---

# Active Companion System

For most of the game:

- One companion may be Active.
- The active companion travels with the player.
- The active companion participates in combat.
- The active companion assists with exploration.
- The active companion gains experience.

Players may own many companions but choose which one to bring before leaving the Hub World.

Late in the game, players unlock the ability to bring a second active companion, dramatically expanding tactical possibilities and rewarding long-term progression.

---

# Companion Collection

Players acquire companions through a variety of methods, including:

- Rescuing them.
- Discovering them while exploring.
- Purchasing them from specialized merchants.
- Completing adventures.
- Liberating regions.

Companion acquisition should feel exciting and memorable.

Players should look forward to expanding their collection throughout the game.

---

# Companion Roles

Each companion should contribute in multiple ways.

Examples include:

Combat
- Damage
- Tanking
- Support
- Healing
- Crowd control
- Status effects

Exploration
- Reveal hidden objects
- Track rare creatures
- Detect resources
- Access hidden areas
- Solve environmental puzzles

World Interaction
- Ignite fires
- Freeze water
- Break obstacles
- Grow plants
- Activate ancient machinery
- Harvest special resources

Utility
- Improve gathering
- Increase crafting efficiency
- Reduce travel risks
- Enhance loot discovery

Every companion should provide value beyond combat.

---

# Companion Identity

Every companion should have:

- A unique visual identity.
- A distinct personality.
- Preferred combat behavior.
- Strengths.
- Weaknesses.
- Elemental affinities.
- Exploration abilities.
- Utility abilities.

Players should remember companions by their personalities and abilities rather than their statistics alone.

---

# Companion Progression

Companions grow through:

- Experience
- Leveling
- Evolutions
- New abilities
- Equipment (if applicable)
- Bond progression
- Special upgrades

Growth should unlock new gameplay possibilities rather than simply increasing damage numbers.

---

# Companion Synergy

Companions should interact naturally with:

- Player abilities
- Equipment
- Damage types
- Crafting
- World mechanics
- Other companions (late game)

The strongest builds emerge from thoughtful combinations rather than individual power.

---

# Companion AI

Companion AI should emphasize:

- Staying near the player.
- Intelligent target selection.
- Avoiding hazards.
- Assisting rather than dominating combat.
- Reacting appropriately to player actions.

Players should feel supported rather than overshadowed.

---

# Damage Types & World Interaction

Damage types are universal systems.

Whether produced by:

- The player
- A companion
- An enemy
- A trap
- The environment

…the same interaction rules should apply.

Examples:

Fire
- Burns enemies.
- Ignites grass.
- Lights torches.
- Destroys vines.
- Melts wax.

Ice
- Freezes water.
- Slows enemies.
- Creates temporary bridges.
- Preserves food.

Lightning
- Chains through wet enemies.
- Powers machinery.
- Stuns mechanical foes.

Poison
- Weakens enemies.
- Contaminates water.
- Destroys plant life.

The world should react consistently to every damage source.

---

# Emergent Gameplay

Companions are designed to encourage emergent problem solving.

Players should frequently discover creative solutions by combining:

- Companion abilities.
- Player abilities.
- Equipment.
- Elements.
- Environmental interactions.

The game should reward experimentation.

---

# Design Principles

Companions should:

- Feel like trusted partners.
- Encourage collection.
- Reward long-term investment.
- Create memorable stories.
- Expand player expression.
- Strengthen interconnected systems.

No companion should become permanently obsolete.

Every companion should remain useful through unique abilities, utility, or synergies.

---

# Engineering Considerations

Companions should be built as modular, data-driven entities.

Behavior, progression, abilities, traits, and world interactions should primarily be defined through data rather than hard-coded logic.

This allows designers to add new companions with minimal engineering effort.

---

# Open Questions

- How many total companions at launch?
- Can companions evolve multiple times?
- Do companions wear equipment?
- How are companion abilities unlocked?
- Can companions be bred or fused?
- How is bond progression measured?

---

# Related Documents

- Docs/Systems/PROGRESSION.md
- Docs/Systems/COMBAT.md
- Docs/Systems/PLAYER.md
- Docs/Systems/WORLD.md
- Docs/Systems/DAMAGE_SYSTEM.md
- Docs/Systems/ABILITY_SYSTEM.md